let button_home = document.getElementsByClassName('button-home')[0]
let button_layout = document.getElementsByClassName('button-layout')


button_home.addEventListener('click', function(){
  console.log("clicado", button_layout);
})

;
